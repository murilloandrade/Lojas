package com.github.murilloandrade.lojas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojasApplication {
    public static void main(String[] args) {
        SpringApplication.run(LojasApplication.class, args);
    }

}
