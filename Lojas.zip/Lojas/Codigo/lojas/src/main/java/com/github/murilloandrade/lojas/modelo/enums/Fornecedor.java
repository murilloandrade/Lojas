package com.github.murilloandrade.lojas.modelo.enums;

public enum Fornecedor {
    Fornecedor1, Fornecedor2, Fornecedor3, Fornecedor4, Outros;
}
